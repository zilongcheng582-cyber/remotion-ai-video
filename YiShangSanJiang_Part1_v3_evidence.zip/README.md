# 衣上三江 · 第一章 v3 Evidence（黄河绘景素材替换）

| 目录 | 内容 |
|---|---|
| `SOURCES.md` | 素材来源登记（新黄河图为 AI 辅助素材，非实拍；未确认权利标“待核实”） |
| `01_v2_original_record/` | v2 原始开发记录：v2 README、v2 图层脚本、v2 相机参数、v2 源码包及其 53 个文件的 SHA-256；`v2_rendered_stills_…jpg` 为本会话从 v2 源码实际渲染的 v2 画面（标注为 v2） |
| `02_v3_replacement_process/` | 本次替换过程：`PROCESS.md`、河道标定（含被否决的第 1 轮）、水体掩膜、4 轮 QC 联系表 |
| `03_v3_final_keyframes/` | **从 v3 正式 MP4 解码的关键帧**（20 帧 + 联系表），非预览图、非旧版截图 |
| `04_handoff_seam/` | 末帧 v2/v3 对比与交接参数 |
| `05_verification/` | ffprobe、像素/PSNR 比对、音频、白边与跳变检查 |
| `06_version_diff/` | v2→v3 差异说明、代码 diff、文件哈希、git 记录 |

说明：作者此前的 v2 Evidence 包未随本次任务上传，因此 01 目录只包含 v2 源码包中能取得的真实记录，没有复制或伪造任何旧证据。第二章正式版文件也未提供，接口核对方法与限制见 `05_verification/VERIFICATION.md` 第 4 节。
