# v3 黄河素材替换过程记录（2026-10-20，本会话真实记录）

范围：只替换第一章黄河绘景素材，不重做动画。服饰、彩带、字幕、音乐、针脚动画、分镜时间表（`constants.ts`）均未修改。

## 1. 恢复 v2 工程
- 解压作者上传的 `YiShangSanJiang_Part1_v2_source.zip`（SHA-256 见 `01_v2_original_record/`），覆盖到仓库，`npm ci` 安装依赖。
- 以 git 提交 `577714b` 固定 v2 基线，后续全部改动均在其上进行，便于逐文件比对。
- 读取 v2 结构：黄河图层只在 f708 之后参与画面（f708 起彩带开始向河道中心线弯曲；f770 起绘景层挂载）。因此 **f0–f707 理论上不受本次替换影响**，后文用实际渲染验证。

## 2. 新图片入库
- 上传文件 `1.webp`（1672×941，无 EXIF/生成器信息）转存为 `references/yssj/ref5_yellow_river_bend_ai.png`，登记为 AI 辅助素材（见 `SOURCES.md`）。

## 3. 河道中心线重新标定（新构图与 v2 不同）
- 第 1 轮：凭全图目测手描 42 个控制点 → `iter1_initial_hand_trace_REJECTED.jpg`。U 形底部中心线贴在外岸、宽度偏大，**判为不合格**。
- 尝试“沿法线自动找两岸”吸附：因沙洲与河水同色，结果错乱，**放弃**（未进入成片）。
- 第 2 轮：生成 2× 放大、25 px 网格的四个局部（`grid_crop_cA…cD.jpg`），逐段读取两岸坐标，重写 51 个控制点与河宽。
- 第 3 轮：水体掩膜加入“低局部纹理”条件（11×11 窗口灰度标准差 < 7），把沙洲从水面中排除；再用该掩膜对中心线做受限自动居中（偏移 ≤ 0.22×河宽，41 点平滑），左上远端发夹弯改圆、交汇口与地平线段保持手描。最终结果：`centreline_calibration.jpg`（红=中心线，橙=±½河宽，青=水体掩膜轮廓），`river_mask_1x.png`。
- 右上方通往地平线的汊道单独加入水体掩膜（ARM），只用于水面着色，不在彩带/针脚路径上，避免交汇口出现色块接缝。

## 4. 分层与镜头
- 脚本 `make_landscape_v3.py` 输出 far / main / near / river / dist 五层（与 v2 渲染代码接口完全一致）。
- 防重影：near 层下方的 main 层用镜像填充，近景视差不会露出同一地貌的第二份拷贝；near 层避开河道 45 px 膨胀区，河岸不滑移。
- 防白边：`landCam` 重新取景 —— f870 全河道入画（z 1.2），f1080 z 1.28，f1260 z 1.5、画面右缘停在图像右缘内 4 px。所有视差层在 f870–f1259 均覆盖全画面（成片逐帧检测见 `05_verification`）。
- 天空/远山：距离场中对地平线以上加 300 px 偏移，避免“由河生长”时天空先于地形出现成孤立亮块（第 1 轮 QC f950 发现）。

## 5. 关键帧 QC 与修复（按时间顺序）
| 轮次 | 文件 | 发现 | 处理 |
|---|---|---|---|
| 1 | `qc_iter1_contact_f720-1259.jpg` | 左上远端发夹弯使彩带出现折角（几何化）；f950 天空先显现为亮块；末帧针脚偏离河心 | 发夹弯改圆；天空延后显现；进入第 3 节第 3 轮标定 |
| 2 | `qc_iter2_contact_band_fold_issue.jpg` | f930–f950 彩带变宽时在急弯内侧扇形折叠 | `ThreadJourney.tsx` 中按局部曲率半径限制彩带宽度（≤1.6R） |
| 3 | `qc_iter3_contact_bend_cap.jpg`、`qc_iter3_v2_left_vs_v3_right_grade_mismatch.jpg` | 折叠消除；但与 v2 并排对比，新素材饱和度偏低（HSV 平均饱和度 60 vs 95），过渡期水面呈粉色 | 对新素材做 LAB 均值/方差 75% 向 v2 `main.png` 对齐 |
| 4 | `qc_iter4_contact_grade_matched.jpg` | 色彩与 v2 一致（末帧饱和度 92.8 vs v2 95.3），水面过渡为 v2 同样的橙黄 | 通过，提交 `ca2e37b`，渲染正式 MP4 |

## 6. 正式渲染
`npx remotion render src/remotion/YiShangSanJiang/index.ts YiShangSanJiang-Part1 out/yssj/YiShangSanJiang_Part1_v3_final.mp4 --concurrency=4`（Chromium headless shell 1194）。
`03_v3_final_keyframes/` 内所有图片均由 ffmpeg 从这份 MP4 逐帧解码，不是 QC 预览图，也不是 v2 截图。

## 7. 本次未完成 / 无法完成的事项
- **第二章正式版文件未随本次任务提供**，无法读取其第一帧做像素级比对。本次按 v2 README 记录的交接约定对齐：末帧为照片质感黄河 + 象牙白→靛蓝针脚、河流/针脚自右缘流出（v2 y≈676 px，v3 y≈672 px）、调色与 Grade 层不变。详见 `04_handoff_seam/`。若第二章首帧含有 v2 黄河画面本身，需拿到第二章文件后再复核。
- 原 v2 Evidence 包未随本次上传，`01_v2_original_record/` 只能保留 v2 源码包中可得的真实记录（README、生成脚本、相机参数、文件哈希清单）以及本会话从 v2 源码实际渲染的 v2 画面。
