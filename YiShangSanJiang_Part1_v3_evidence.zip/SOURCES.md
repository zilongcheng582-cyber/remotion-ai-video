# 衣上三江 · 第一章 v3 — 素材来源登记 (Source Register)

登记日期：2026-10-20　|　适用版本：Part 1 v3（仅黄河绘景素材替换）

| 编号 | 文件 | 用途 | 来源 / 生成方式 | 权利状态 |
|---|---|---|---|---|
| ref5 | `references/yssj/ref5_yellow_river_bend_ai.png`（原上传 `1.webp`，1672×941，SHA-256 `2f9fa7f2…84c5684a5b3`；PNG 转存 SHA-256 `6fd84f02…5ad448`） | **v3 新黄河绘景唯一来源**：生成 `public/yssj/landscape/{far.jpg, main.png, near.png, river.png, dist.png, river_path.json}` | **AI 辅助制作素材**，由作者在 2026-10-20 的本次对话中上传。**不是实拍照片，不得登记为本人实拍。** 文件内无 EXIF/生成器元数据（仅含 ICC profile），所用生成工具、提示词、生成日期及是否以第三方照片为参考，均需作者补充登记。画面中的河流分汊在物理上不完全合理（右上方汊道），与 AI 生成特征一致。 | 待作者补充生成工具名称及其使用条款；若生成时参考了第三方图片，该参考图权利**待核实** |
| ref3 | `references/yssj/ref3_yellow_river_meander.jpg` | v2 黄河绘景来源。**v3 成片中不再使用**，仅作为 v2 开发记录保留在 references/ | 第三方照片（v2 README 已注明） | **待核实**（未变化） |
| ref4 | `references/yssj/ref4_loess_plateau.png` | v2 参考图，v2/v3 均未用于成片图层 | 未在 v2 记录中说明 | **待核实**（未变化） |
| 服饰 | `public/yssj/ref_garment_full.jpg`, `ref_skirt_closeup.png` 及其派生（`garment_full_keyed.png`, `skirt_closeup_keyed.png`, `hem_band.png`） | 第 0–42 秒服饰介绍、彩带针脚 | v2 成片字幕标注为“中央民族大学民族博物馆馆藏”苗族绣花盛装女服；图像拍摄者/授权未在 v2 源码中记录 | **未改动**；权利状态沿用 v2 记录，未在本次核实，**待核实** |
| 音乐 | `public/yssj/audio/part1_ambient.wav` | 全片音频 | v2 脚本 `scripts/yssj/make_ambient.py` 程序生成 | 未改动（SHA-256 与 v2 一致，见 05_verification） |
| 纹理 | `public/yssj/textures/{weave,paper_grain}.png` | 布纹/纸纹叠加 | v2 脚本 `make_textures.py` 程序生成 | 未改动 |

## v3 派生处理（全部由脚本 `scripts/yssj/make_landscape_v3.py` 可复现）
1. ref5 2× Lanczos 放大 → 轻度保边滤波 + 细节增强（与原图 35% 混合，保留真实地貌纹理）→ 饱和度 ×0.84、暖色偏移。
2. LAB 均值/方差 75% 向 v2 `main.png` 的统计值对齐（使新素材与 v2 的黄河色彩一致；第二章文件未提供，无法直接比对其首帧）。
3. 河道：51 个手工控制点（2× 网格放大标定）→ Catmull-Rom → 以“颜色 + 低纹理”水体掩膜（排除沙洲）自动居中微调（偏移上限 0.22×河宽，41 点平滑）。
4. 分层：far（全幅 + 地平线大气雾）、main（地平线以下；近景下方镜像填充，避免视差露出重影）、near（底部前景，避开河道 45 px 膨胀区）、river（水体软边）。

## 未使用
本次未下载、未引用任何网络图片；未使用新的第三方素材。
