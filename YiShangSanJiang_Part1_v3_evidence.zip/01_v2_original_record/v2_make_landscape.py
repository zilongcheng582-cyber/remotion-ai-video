"""Build 2.5D layers from the Yellow River reference photo (ref3) for Part 1, shots 5–6.
Outputs (2× upscaled, painterly-processed) far/main/near/river layers, a distance-to-centreline map
used for the 'terrain grows out of the river' reveal, and the river centreline JSON.
NOTE: derived from a third-party photograph – verify usage rights before public release.
Usage: python3 make_landscape.py <ref3.jpg> <out_dir>"""
import json, sys
import cv2
import numpy as np

src, out = sys.argv[1], sys.argv[2]
S = 2  # upscale factor
im0 = cv2.imread(src)
H0, W0 = im0.shape[:2]

# hand-traced river centreline (photo px), upstream (far left) → downstream (right edge)
CTRL = [(330, 212), (400, 228), (446, 258), (440, 298), (400, 330), (340, 360), (292, 408), (272, 460),
        (286, 512), (330, 550), (400, 568), (470, 568), (540, 553), (598, 528), (630, 480), (626, 420),
        (598, 362), (566, 312), (580, 272), (630, 254), (690, 256), (742, 270), (792, 292), (852, 326),
        (920, 360), (990, 386), (1080, 412)]
WIDTH = [22, 26, 34, 40, 44, 48, 56, 60, 62, 62, 60, 58, 58, 56, 54, 52, 52, 48, 44, 40, 38, 36, 36, 38, 40, 42, 44]

def catmull(pts, seg=20):
    pts = np.array(pts, float); out = []
    for i in range(len(pts) - 1):
        p0, p1, p2, p3 = pts[max(0, i - 1)], pts[i], pts[i + 1], pts[min(len(pts) - 1, i + 2)]
        for t in np.linspace(0, 1, seg, endpoint=False):
            t2, t3 = t * t, t * t * t
            out.append(0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    out.append(pts[-1]); return np.array(out)

line = catmull(CTRL)
wid = np.interp(np.linspace(0, len(WIDTH) - 1, len(line)), np.arange(len(WIDTH)), WIDTH)
seglen = np.r_[0, np.cumsum(np.hypot(*np.diff(line, axis=0).T))]
n = int(seglen[-1] / 4)
s = np.linspace(0, seglen[-1], n)
cl = np.c_[np.interp(s, seglen, line[:, 0]), np.interp(s, seglen, line[:, 1])]
cw = np.interp(s, seglen, wid)
json.dump({"size": [W0, H0], "points": np.round(cl, 1).tolist(), "widths": np.round(cw, 1).tolist()},
          open(f"{out}/river_path.json", "w"))

# ---- river mask: colour segmentation constrained to a corridor around the traced centreline
b, g, r = [im0[..., i].astype(int) for i in range(3)]
water = (((r - g > 25) & (g - b > 5) & (r > 120)) | ((r > 200) & (g > 170) & (b > 110) & (r - b > 40))).astype(np.uint8) * 255
corr = np.zeros((H0, W0), np.uint8); core = np.zeros((H0, W0), np.uint8)
for (x, y), w in zip(cl, cw):
    cv2.circle(corr, (int(x), int(y)), int(w * 1.15), 255, -1)
    cv2.circle(core, (int(x), int(y)), int(w * 0.42), 255, -1)
water[:245, 590:770] = 0  # sun haze above the bend is not water
river = cv2.bitwise_or(cv2.bitwise_and(water, corr), core)
river = cv2.morphologyEx(river, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
river = cv2.morphologyEx(river, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
# drop isolated specks – keep only the connected water body
nl, lab, st, _ = cv2.connectedComponentsWithStats(river)
river = np.where(np.isin(lab, [i for i in range(1, nl) if st[i, 4] > 1500]), 255, 0).astype(np.uint8)

# ---- painterly, slightly warm grade (keeps natural loess greens/ochres, softens upscale)
up = cv2.resize(im0, (W0 * S, H0 * S), interpolation=cv2.INTER_LANCZOS4)
paint = cv2.edgePreservingFilter(up, flags=cv2.RECURS_FILTER, sigma_s=24, sigma_r=0.22)
det = cv2.detailEnhance(paint, sigma_s=8, sigma_r=0.12)
img = cv2.addWeighted(paint, 0.55, det, 0.45, 0).astype(np.float32)
hsv = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_BGR2HSV).astype(np.float32)
hsv[..., 1] *= 0.86
img = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR).astype(np.float32)
img = img * np.array([0.94, 0.99, 1.04])  # warm
img = np.clip(img, 0, 255)
H, W = img.shape[:2]
yy = np.linspace(0, 1, H)[:, None, None]

def save_rgba(name, rgb, alpha):
    a = np.clip(alpha, 0, 1)
    cv2.imwrite(f"{out}/{name}", np.dstack([np.clip(rgb, 0, 255), a[..., None] * 255 if a.ndim == 2 else a * 255]).astype(np.uint8))

def ss(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t)

# far: whole frame with aerial haze toward the horizon
haze = np.array([214, 226, 236], np.float32)  # BGR warm-white haze
far = img * (1 - 0.55 * (1 - ss(0.12, 0.5, yy))) + haze * 0.55 * (1 - ss(0.12, 0.5, yy))
cv2.imwrite(f"{out}/far.jpg", np.clip(far, 0, 255).astype(np.uint8), [cv2.IMWRITE_JPEG_QUALITY, 92])

# main: everything below the distant ridges
y2 = np.linspace(0, H0, H)[:, None] * np.ones((1, W))
mainA = ss(150, 235, y2)
mainRGB = img * (1 - 0.22 * (1 - ss(0.2, 0.6, yy))) + haze * 0.22 * (1 - ss(0.2, 0.6, yy))
save_rgba("main.png", mainRGB, mainA)

# river: just the water (soft edge)
riverUp = cv2.GaussianBlur(cv2.resize(river, (W, H), interpolation=cv2.INTER_LINEAR), (0, 0), 2.2).astype(np.float32) / 255
save_rgba("river.png", mainRGB, riverUp)

# near: foreground hills (bottom band), keeping clear of the river so banks never slip
dil = cv2.dilate(river, np.ones((41, 41), np.uint8))
dilUp = cv2.GaussianBlur(cv2.resize(dil, (W, H)), (0, 0), 12).astype(np.float32) / 255
nearA = ss(455, 540, y2) * (1 - dilUp)
save_rgba("near.png", img * 0.96, nearA)

# distance from centreline (photo px / 520 → 0..1) for the reveal masks
cline = np.full((H0, W0), 255, np.uint8)
cv2.polylines(cline, [cl.astype(np.int32)], False, 0, 1)
d = cv2.distanceTransform(cline, cv2.DIST_L2, 5)
d = cv2.resize(d, (W, H), interpolation=cv2.INTER_LINEAR)
cv2.imwrite(f"{out}/dist.png", np.clip(d / 520 * 255, 0, 255).astype(np.uint8))
print("ok", W, H, "centreline pts", len(cl))
