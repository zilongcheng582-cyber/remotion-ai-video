"""Original ambient bed for 衣上三江 Part 1 (42 s, revision 2 edit). Pure synthesis – no samples, no third-party music.
Kept quiet and low-mid sparse so narration can sit on top in the final edit.
Usage: python3 make_ambient.py <out.wav>"""
import sys, wave
import numpy as np

SR = 48000
DUR = 42.0
N = int(SR * DUR)
t = np.arange(N) / SR
rs = np.random.RandomState(1980)

def env(points):
    xs, ys = zip(*points)
    return np.interp(t, xs, ys)

def lowpass(x, cutoff):
    a = np.exp(-2 * np.pi * cutoff / SR)
    y = np.empty_like(x); acc = 0.0
    for i in range(len(x)):  # one-pole (fine for 34 s)
        acc = (1 - a) * x[i] + a * acc
        y[i] = acc
    return y

def lp_fast(x, cutoff):
    # FFT brickwall-ish smooth lowpass
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    X *= 1 / (1 + (f / cutoff) ** 4)
    return np.fft.irfft(X, len(x))

def bp_fast(x, lo, hi):
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    X *= (1 / (1 + (lo / np.maximum(f, 1)) ** 4)) * (1 / (1 + (f / hi) ** 4))
    return np.fft.irfft(X, len(x))

D2 = 73.42
def pad(freqs, amp, detune=0.0025):
    out = np.zeros(N)
    for i, fr in enumerate(freqs):
        for d in (-detune, 0, detune):
            ph = rs.rand() * 2 * np.pi
            out += np.sin(2 * np.pi * fr * (1 + d) * t + ph + 0.4 * np.sin(2 * np.pi * 0.07 * t + i))
    return out * amp / (3 * len(freqs))

L = np.zeros(N); R = np.zeros(N)

# 1. room tone / air – darkness of the gallery, later the wind over the plateau
air = rs.randn(N)
room = lp_fast(air, 380) * env([(0, 0), (2, 0.5), (21, 0.45), (30, 0.25), (42, 0.25)])
wind = bp_fast(rs.randn(N), 250, 1400)
wind *= env([(0, 0), (30, 0), (34, 0.5), (37, 0.75), (40, 0.6), (42, 0.5)])
wind *= 0.65 + 0.35 * np.sin(2 * np.pi * 0.11 * t) ** 2
L += 0.05 * room + 0.035 * wind
R += 0.05 * np.roll(room, 911) + 0.035 * np.roll(wind, 1733)

# 2. drone pad – D / A, opening to a sus2 colour in the landscape, cooler (B, F#) toward Part 2
p1 = pad([D2, D2 * 1.5, D2 * 2], 1.0) * env([(0, 0), (1, 0.0), (5, 0.35), (13, 0.5), (21, 0.6), (30, 0.75), (36, 0.75), (40, 0.6), (42, 0.55)])
p2 = pad([D2 * 2 * 1.125, D2 * 3], 0.8) * env([(0, 0), (13, 0), (17, 0.35), (29, 0.4), (33, 0.6), (38, 0.6), (42, 0.35)])
p3 = pad([D2 * 2 * 1.6818, D2 * 2 * 1.25 * 1.0], 0.7) * env([(0, 0), (37, 0), (40, 0.4), (42, 0.5)])
pads = lp_fast(p1 + p2 + p3, 900)
L += 0.11 * pads
R += 0.11 * np.roll(pads, 480)

# 3. plucked thread – Karplus-Strong, D-major pentatonic, sparse
def pluck(freq, dur=4.0, bright=0.5):
    n = int(SR * dur)
    period = int(SR / freq)
    buf = rs.uniform(-1, 1, period) * bright + rs.uniform(-1, 1, period) * (1 - bright) * 0.3
    out = np.empty(n)
    for i in range(n):
        out[i] = buf[i % period]
        buf[i % period] = 0.996 * 0.5 * (buf[i % period] + buf[(i + 1) % period])
    return out * np.exp(-np.arange(n) / (SR * dur * 0.35))

notes = [  # (time s, freq Hz, gain, pan) – sparse, follows the edit
    (5.2, 293.66, 0.3, 0.0),     # garment appears
    (15.6, 440.0, 0.3, -0.15),   # three-rivers diagram
    (17.2, 369.99, 0.25, 0.2),
    (21.6, 440.0, 0.5, -0.2),    # embroidery begins to move
    (23.0, 587.33, 0.42, 0.15),
    (24.5, 493.88, 0.38, -0.05),
    (26.2, 659.25, 0.38, 0.25),
    (28.0, 369.99, 0.36, -0.3),
    (30.4, 293.66, 0.45, 0.0),   # becomes the river
    (33.2, 440.0, 0.32, 0.3),
    (37.4, 587.33, 0.34, -0.2),  # journey
    (39.4, 493.88, 0.32, 0.2),
    (41.0, 739.99, 0.28, 0.1),
]
pl_l = np.zeros(N); pl_r = np.zeros(N)
for tt, fr, g, pan in notes:
    s = pluck(fr, 4.0, 0.45)
    s = lp_fast(np.pad(s, (0, 0)), 2600)
    i0 = int(tt * SR); i1 = min(N, i0 + len(s))
    pl_l[i0:i1] += s[: i1 - i0] * g * (1 - pan) * 0.5
    pl_r[i0:i1] += s[: i1 - i0] * g * (1 + pan) * 0.5

# simple stereo reverb: convolution with decaying noise
def reverb(x, seconds=3.2, seed=0):
    r = np.random.RandomState(seed)
    n = int(SR * seconds)
    ir = r.randn(n) * np.exp(-np.arange(n) / (SR * seconds / 6))
    ir = lp_fast(np.pad(ir, (0, N - n)), 3500)[:n]
    ir /= np.sqrt((ir ** 2).sum())
    m = len(x) + n
    y = np.fft.irfft(np.fft.rfft(x, m) * np.fft.rfft(ir, m), m)[: len(x)]
    return y
L += 0.09 * pl_l + 0.12 * reverb(pl_l, seed=1)
R += 0.09 * pl_r + 0.12 * reverb(pl_r, seed=2)

# 4. water swell under the thread-to-river transformation (29–36 s)
water = bp_fast(rs.randn(N), 90, 600) * env([(0, 0), (29, 0), (32.5, 0.8), (36, 0.55), (42, 0.45)])
water *= 0.7 + 0.3 * np.sin(2 * np.pi * 0.23 * t)
L += 0.06 * water; R += 0.06 * np.roll(water, 2400)

mix = np.stack([L, R], 1)
mix -= mix.mean(0)
peak = np.abs(mix).max()
mix *= 10 ** (-9 / 20) / peak  # peak -9 dBFS, sits well under narration
# micro fades: start in silence, end sustained (Part 2 can crossfade)
mix[: int(0.05 * SR)] *= np.linspace(0, 1, int(0.05 * SR))[:, None]
pcm = (np.clip(mix, -1, 1) * 32767).astype(np.int16)
with wave.open(sys.argv[1], "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes(pcm.tobytes())
print("wrote", sys.argv[1], DUR, "s")
