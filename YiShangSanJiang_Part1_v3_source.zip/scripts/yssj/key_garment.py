"""Remove the orange museum-catalogue backdrop from the garment photos.
Usage: python3 key_garment.py <in> <out.png>
Pixels close to the backdrop orange that are connected to the image border become transparent."""
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

src, dst = sys.argv[1], sys.argv[2]
im = Image.open(src).convert("RGB")
a = np.asarray(im).astype(np.float32)
# sample backdrop colour from corners
h, w, _ = a.shape
corners = np.concatenate([a[:8, :8].reshape(-1, 3), a[:8, -8:].reshape(-1, 3), a[-8:, :8].reshape(-1, 3), a[-8:, -8:].reshape(-1, 3)])
bg = np.median(corners, axis=0)
d = np.sqrt(((a - bg) ** 2).sum(-1))
# also accept yellow/orange hue family with high saturation (catches JPEG shading)
r, g, b = a[..., 0], a[..., 1], a[..., 2]
orange = (r > 200) & (g > 120) & (g < 215) & (b < 90) & (r - b > 150)
cand = (d < 70) | orange
mask = Image.fromarray((cand * 255).astype(np.uint8))
# keep only regions connected to border: floodfill marker value 128 from border seeds
m = mask.copy()
for x in range(0, w, 3):
    for y in (0, h - 1):
        if m.getpixel((x, y)) == 255:
            ImageDraw.floodfill(m, (x, y), 128)
for y in range(0, h, 3):
    for x in (0, w - 1):
        if m.getpixel((x, y)) == 255:
            ImageDraw.floodfill(m, (x, y), 128)
bgmask = (np.asarray(m) == 128)
# scan borders of the catalogue photo are never cloth
bgmask[:3, :] = True; bgmask[-3:, :] = True; bgmask[:, :3] = True; bgmask[:, -3:] = True
alpha = Image.fromarray(((~bgmask) * 255).astype(np.uint8))
alpha = alpha.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(0.8))
# de-spill orange on the edge: pull edge pixels toward darker neutral
al = np.asarray(alpha).astype(np.float32) / 255
edge = (al > 0) & (al < 1)
out = a.copy()
lum = (0.3 * r + 0.59 * g + 0.11 * b)[..., None]
# only treat a thin band next to the removed backdrop, so interior gold/yellow thread stays intact
near = np.asarray(Image.fromarray((bgmask * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(5))) > 0
spill = ((orange | (d < 90)) & ~bgmask & near)[..., None] * 1.0
out = out * (1 - 0.85 * spill) + lum * 0.35 * 0.85 * spill
rgba = np.dstack([np.clip(out, 0, 255), al * 255]).astype(np.uint8)
Image.fromarray(rgba, "RGBA").save(dst)
print(dst, im.size, "bg", bg, "transparent %.1f%%" % (100 * bgmask.mean()))
