#!/usr/bin/env bash
# Render QC stills for 衣上三江 Part 1 into a contact sheet.  Usage: qc_stills.sh <outdir> <frame...>
set -e
OUT=$1; shift
BX=${REMOTION_BROWSER:-/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell}
rm -rf "$OUT/bundle"
npx remotion bundle src/remotion/YiShangSanJiang/index.ts --out-dir "$OUT/bundle" --log=error >/dev/null
for fr in "$@"; do
  npx remotion still "$OUT/bundle" YiShangSanJiang-Part1 "$OUT/qc_$fr.jpg" --frame=$fr --scale=0.5 --browser-executable=$BX --log=error
done
python3 - "$OUT" "$@" <<'PY'
import sys
from PIL import Image, ImageDraw
out, frames = sys.argv[1], sys.argv[2:]
ims = [Image.open(f"{out}/qc_{f}.jpg") for f in frames]
w, h = ims[0].size
cols = 2
rows = (len(ims) + 1) // 2
sheet = Image.new("RGB", (w * cols, h * rows))
for i, (im, f) in enumerate(zip(ims, frames)):
    ImageDraw.Draw(im).text((10, 10), f"f{f}", fill=(255, 80, 80))
    sheet.paste(im, ((i % cols) * w, (i // cols) * h))
sheet.save(f"{out}/contact.jpg", quality=88)
PY
