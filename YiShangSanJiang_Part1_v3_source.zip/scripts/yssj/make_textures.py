"""Generate original seamless textures for 衣上三江 (paper grain + plain-weave cloth).
Usage: python3 make_textures.py <out_dir>"""
import sys
import numpy as np
from PIL import Image

out = sys.argv[1]
rs = np.random.RandomState(7)

def blur_wrap(a, k):
    # separable box blur with wrap-around (seamless)
    for ax in (0, 1):
        acc = np.zeros_like(a)
        for s in range(-k, k + 1):
            acc += np.roll(a, s, axis=ax)
        a = acc / (2 * k + 1)
    return a

# --- paper grain: soft cloudy formation + short fibres, mid-grey centred (for overlay/soft-light)
N = 512
cloud = sum(blur_wrap(rs.randn(N, N), k) * w for k, w in ((24, 3.0), (8, 1.4), (2, 0.6)))
fib = np.zeros((N, N))
for _ in range(1400):
    x, y = rs.randint(0, N, 2)
    ang = rs.rand() * np.pi
    ln = rs.randint(6, 22)
    v = rs.choice([-1, 1]) * (0.4 + rs.rand() * 0.6)
    for t in range(ln):
        fib[int(y + np.sin(ang) * t) % N, int(x + np.cos(ang) * t) % N] += v
fib = blur_wrap(fib, 1)
g = cloud / np.abs(cloud).max() * 0.6 + fib * 0.5 + rs.randn(N, N) * 0.12
g = 128 + np.clip(g, -1, 1) * 60
Image.fromarray(g.astype(np.uint8), "L").save(f"{out}/paper_grain.png")

# --- plain weave cloth: warp/weft threads with slubs, mid-grey centred
N = 192
y, x = np.mgrid[0:N, 0:N].astype(float)
p = 6.0  # thread pitch in px
wx = np.sin(np.pi * x / p) ** 2
wy = np.sin(np.pi * y / p) ** 2
over = ((np.floor(x / p) + np.floor(y / p)) % 2 == 0)
cloth = np.where(over, wx * 0.9 + 0.1 * wy, wy * 0.9 + 0.1 * wx)
slub = blur_wrap(rs.randn(N, N), 3) * 0.6
cloth = (cloth - 0.5) * 1.3 + slub * 0.5 + rs.randn(N, N) * 0.05
c = 128 + np.clip(cloth, -1, 1) * 70
Image.fromarray(c.astype(np.uint8), "L").save(f"{out}/weave.png")
print("ok")
