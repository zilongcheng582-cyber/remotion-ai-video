"""v3: build the 2.5D Yellow River layers for Part 1 (shots 5–6) from the new AI-assisted river-bend
image (ref5, 1672×941). Same outputs/contract as make_landscape.py (v2): far/main/near/river layers,
a distance-to-centreline map for the 'terrain grows out of the river' reveal, and river_path.json.
Changes vs v2: re-traced centreline/widths for the new bend, a second water corridor for the arm that
leaves the junction toward the top-right horizon (so the water tint has no seam there), and the main
layer is filled under the near hills (mirror fill) so near-layer parallax never exposes a duplicate.
NOTE: ref5 is an AI-assisted image supplied by the author – see SOURCES in the evidence pack.
Usage: python3 make_landscape_v3.py <ref5.png> <out_dir> [qc_dir]"""
import json, sys
import cv2
import numpy as np

src, out = sys.argv[1], sys.argv[2]
S = 2  # upscale factor
DIST_NORM = 830  # photo px per dist unit (v2: 520 on a 1080-wide photo; keeps the same on-screen reveal speed)
im0 = cv2.imread(src)
H0, W0 = im0.shape[:2]

# hand-traced river centreline (photo px), upstream (far horizon, left) → downstream (right edge)
CTRL = [(492, 157), (445, 180), (380, 200), (300, 216), (252, 228), (230, 241), (248, 252), (290, 256), (380, 269), (480, 288), (580, 310), (650, 322), (712, 334), (742, 352), (738, 378), (705, 402), (650, 425), (580, 452), (510, 478), (458, 505), (430, 540), (420, 580), (420, 620), (432, 660), (462, 698), (510, 720), (580, 735), (660, 748), (740, 758), (820, 763), (900, 760), (960, 742), (1010, 712), (1050, 680), (1078, 640), (1080, 600), (1062, 550), (1032, 500), (988, 452), (950, 412), (952, 386), (990, 372), (1040, 362), (1090, 354), (1150, 364), (1200, 382), (1300, 422), (1400, 462), (1500, 497), (1600, 529), (1672, 543)]
WIDTH = [8, 12, 16, 20, 22, 24, 26, 28, 32, 36, 40, 50, 62, 70, 72, 72, 72, 74, 80, 88, 94, 98, 102, 106, 108, 106, 104, 100, 96, 92, 92, 96, 106, 116, 126, 132, 130, 124, 112, 92, 66, 40, 34, 36, 44, 50, 52, 40, 36, 36, 36]
# the arm that climbs from the junction toward the horizon (water mask only – not on the thread path)
ARM = [(1110, 345), (1104, 318), (1118, 296), (1160, 276), (1210, 262), (1250, 252)]
ARM_W = [56, 50, 46, 38, 30, 20]


def catmull(pts, seg=20):
    pts = np.array(pts, float); out = []
    for i in range(len(pts) - 1):
        p0, p1, p2, p3 = pts[max(0, i - 1)], pts[i], pts[i + 1], pts[min(len(pts) - 1, i + 2)]
        for t in np.linspace(0, 1, seg, endpoint=False):
            t2, t3 = t * t, t * t * t
            out.append(0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    out.append(pts[-1]); return np.array(out)


def resample(ctrl, width, step=4):
    line = catmull(ctrl)
    wid = np.interp(np.linspace(0, len(width) - 1, len(line)), np.arange(len(width)), width)
    seglen = np.r_[0, np.cumsum(np.hypot(*np.diff(line, axis=0).T))]
    s = np.linspace(0, seglen[-1], int(seglen[-1] / step))
    return np.c_[np.interp(s, seglen, line[:, 0]), np.interp(s, seglen, line[:, 1])], np.interp(s, seglen, wid)


cl, cw = resample(CTRL, WIDTH)
al, aw = resample(ARM, ARM_W)

# ---- water colour: silt-laden water, incl. the greyer hazy reaches that reflect the sky
b, g, r = [im0[..., i].astype(int) for i in range(3)]
hsv = cv2.cvtColor(im0, cv2.COLOR_BGR2HSV).astype(int)
silt = (r - g > 12) & (g - b > 12) & (r > 150) & (r - b > 40)
hazy = (hsv[..., 2] > 140) & (hsv[..., 1] < 70) & (np.abs(r - g) < 22)
# sandbars share the silt colour, so water must also be smooth (low local contrast)
gy = cv2.cvtColor(im0, cv2.COLOR_BGR2GRAY).astype(np.float32)
mu = cv2.blur(gy, (11, 11))
smooth = np.sqrt(np.maximum(cv2.blur(gy * gy, (11, 11)) - mu * mu, 0)) < 7
water = ((silt | hazy) & smooth).astype(np.uint8) * 255
water = cv2.morphologyEx(water, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
water = cv2.dilate(water, np.ones((5, 5), np.uint8))  # give back the bank pixels the contrast test trims


def river_mask(cl, cw):
    """water colour mask inside a corridor around the centreline (+ the junction arm)"""
    corr = np.zeros((H0, W0), np.uint8); core = np.zeros((H0, W0), np.uint8)
    for (x, y), w in list(zip(cl, cw)) + list(zip(al, aw)):
        cv2.circle(corr, (int(x), int(y)), int(w * 0.62 + 3), 255, -1)
        cv2.circle(core, (int(x), int(y)), int(w * 0.30), 255, -1)
    m = cv2.bitwise_or(cv2.bitwise_and(water, corr), core)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    nl, lab, st, _ = cv2.connectedComponentsWithStats(m)
    return np.where(np.isin(lab, [i for i in range(1, nl) if st[i, 4] > 1500]), 255, 0).astype(np.uint8)


def refine(cl, cw, mask, cap=0.22, win=41):
    """Nudge the hand trace to the middle of the water: bank-to-bank march along each normal, offset capped
    at cap·w and smoothed over `win` samples; unreliable sections (junction, horizon) keep the hand trace."""
    t = np.gradient(cl, axis=0); t /= np.linalg.norm(t, axis=1)[:, None]
    n = np.c_[-t[:, 1], t[:, 0]]
    off = np.zeros(len(cl))
    for i, (p, w) in enumerate(zip(cl, cw)):
        ext = []
        for sgn in (1, -1):
            k = 0
            while k < w:
                x, y = (p + n[i] * sgn * (k + 1)).astype(int)
                if not (0 <= x < W0 and 0 <= y < H0) or mask[y, x] == 0:
                    break
                k += 1
            ext.append(k)
        if w > 30 and min(ext) > 2 and max(ext) < w * 0.95:
            off[i] = np.clip((ext[0] - ext[1]) / 2, -cap * w, cap * w)
    off = np.convolve(np.pad(off, win // 2, mode="edge"), np.ones(win) / win, mode="valid")
    return cl + n * off[:, None]


cl = refine(cl, cw, river_mask(cl, cw))
json.dump({"size": [W0, H0], "points": np.round(cl, 1).tolist(), "widths": np.round(cw, 1).tolist()},
          open(f"{out}/river_path.json", "w"))

river = river_mask(cl, cw)
if len(sys.argv) > 3:  # optional QC dir: 1× water mask
    cv2.imwrite(f"{sys.argv[3]}/river_mask_1x.png", river)
    qc = im0.copy()
    cnt, _ = cv2.findContours(river, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cv2.drawContours(qc, cnt, -1, (255, 255, 0), 1)
    t = np.gradient(cl, axis=0); t /= np.linalg.norm(t, axis=1)[:, None]; nn = np.c_[-t[:, 1], t[:, 0]]
    for k in (-0.5, 0.5):
        cv2.polylines(qc, [(cl + nn * cw[:, None] * k).astype(np.int32)], False, (0, 200, 255), 1)
    cv2.polylines(qc, [cl.astype(np.int32)], False, (0, 0, 255), 2)
    cv2.imwrite(f"{sys.argv[3]}/centreline_calibration.jpg", qc)

# ---- photographic grade: gentle edge-preserving upscale, keep real loess / vegetation detail
up = cv2.resize(im0, (W0 * S, H0 * S), interpolation=cv2.INTER_LANCZOS4)
paint = cv2.edgePreservingFilter(up, flags=cv2.RECURS_FILTER, sigma_s=18, sigma_r=0.18)
det = cv2.detailEnhance(paint, sigma_s=6, sigma_r=0.10)
img = cv2.addWeighted(up, 0.35, cv2.addWeighted(paint, 0.55, det, 0.45, 0), 0.65, 0).astype(np.float32)
hsv2 = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_BGR2HSV).astype(np.float32)
hsv2[..., 1] *= 0.84  # the source is saturated; bring it toward the v2 palette
img = cv2.cvtColor(hsv2.astype(np.uint8), cv2.COLOR_HSV2BGR).astype(np.float32)
img = np.clip(img * np.array([0.93, 0.99, 1.05]), 0, 255)  # warm
# match the v2 landscape grade (LAB mean/std of v2 main.png, measured on its opaque area) so the new
# source sits in the same colour world as v2's Yellow River (the hand-off look Part 2 was cut against)
V2_LAB_MEAN, V2_LAB_STD, MATCH = np.array([109.5, 126.6, 149.5]), np.array([53.1, 8.3, 16.0]), 0.75
lab = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_BGR2LAB).astype(np.float32)
ref = lab[int(H0 * S * 0.16):]  # below the horizon, like v2 main's opaque area
mu, sd = ref.reshape(-1, 3).mean(0), ref.reshape(-1, 3).std(0)
tgt = (lab - mu) * (V2_LAB_STD / sd) + V2_LAB_MEAN
lab = lab + MATCH * (tgt - lab)
img = cv2.cvtColor(np.clip(lab, 0, 255).astype(np.uint8), cv2.COLOR_LAB2BGR).astype(np.float32)
H, W = img.shape[:2]
yy = np.linspace(0, 1, H)[:, None, None]
y2 = np.linspace(0, H0, H)[:, None] * np.ones((1, W))


def save_rgba(name, rgb, alpha):
    a = np.clip(alpha, 0, 1)
    rgb = np.where(a[..., None] > 0, rgb, 0)  # blank fully transparent pixels: smaller PNGs
    cv2.imwrite(f"{out}/{name}", np.dstack([np.clip(rgb, 0, 255), a[..., None] * 255]).astype(np.uint8))


def ss(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t)


haze = np.array([216, 226, 234], np.float32)  # BGR warm-white haze

# far: whole frame with aerial haze toward the horizon
hz = (1 - ss(0.10, 0.42, yy))
far = img * (1 - 0.5 * hz) + haze * 0.5 * hz
cv2.imwrite(f"{out}/far.jpg", np.clip(far, 0, 255).astype(np.uint8), [cv2.IMWRITE_JPEG_QUALITY, 92])

# near: foreground hills (bottom band), kept clear of the river so the banks never slip
dil = cv2.dilate(river, np.ones((45, 45), np.uint8))
dilUp = cv2.GaussianBlur(cv2.resize(dil, (W, H)), (0, 0), 12).astype(np.float32) / 255
nearA = ss(790, 860, y2) * (1 - dilUp)

# main: everything below the distant ridges; under the near hills, mirror-fill from above the near edge
mainRGB = img * (1 - 0.18 * (1 - ss(0.14, 0.5, yy))) + haze * 0.18 * (1 - ss(0.14, 0.5, yy))
edge = int(790 * S)
fill = mainRGB.copy()
src_rows = np.clip(2 * edge - np.arange(edge, H), 0, H - 1)
fill[edge:] = mainRGB[src_rows]
mainFilled = mainRGB * (1 - nearA[..., None]) + fill * nearA[..., None]
mainA = ss(92, 150, y2)
save_rgba("main.png", mainFilled, mainA)
save_rgba("near.png", img * 0.97, nearA)

# river: just the water (soft edge), taken from the un-filled main grade
riverUp = cv2.GaussianBlur(cv2.resize(river, (W, H), interpolation=cv2.INTER_LINEAR), (0, 0), 2.0).astype(np.float32) / 255
save_rgba("river.png", mainRGB, riverUp)

# distance from centreline (photo px / DIST_NORM → 0..1) for the reveal masks
cline = np.full((H0, W0), 255, np.uint8)
cv2.polylines(cline, [cl.astype(np.int32)], False, 0, 1)
d = cv2.distanceTransform(cline, cv2.DIST_L2, 5)
d += 300 * (1 - ss(70, 150, np.arange(H0)[:, None]))  # sky / horizon haze revealed last, never as a bare patch
d = cv2.resize(d, (W, H), interpolation=cv2.INTER_LINEAR)
cv2.imwrite(f"{out}/dist.png", np.clip(d / DIST_NORM * 255, 0, 255).astype(np.uint8))
print("ok", W, H, "centreline pts", len(cl))
