"""Unwrap a strip of the real embroidered hem (close-up photo) into a straight texture band.
The band is later re-mapped along animated paths on a canvas, keeping the original stitches/colours.
Usage: python3 extract_band.py <skirt_closeup_keyed.png> <out.png> <offset_px> <half_height_px>"""
import sys, json
import cv2
import numpy as np

src, out, off, hh = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4])
im = cv2.imread(src, cv2.IMREAD_UNCHANGED).astype(np.float32)
P = [[180, 505], [220, 524], [260, 546], [300, 570], [340, 584], [380, 597], [420, 610], [460, 620], [500, 626], [540, 631],
     [580, 634], [620, 634], [660, 632], [700, 626], [740, 618], [780, 607], [820, 596], [860, 586], [900, 571], [940, 557], [975, 545]]

def catmull(pts, seg=12):
    pts = np.array(pts, float); o = []
    for i in range(len(pts) - 1):
        p0, p1, p2, p3 = pts[max(0, i - 1)], pts[i], pts[i + 1], pts[min(len(pts) - 1, i + 2)]
        for t in np.linspace(0, 1, seg, endpoint=False):
            t2, t3 = t * t, t ** 3
            o.append(0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
    o.append(pts[-1]); return np.array(o)

c = catmull(P)
L = np.r_[0, np.cumsum(np.hypot(*np.diff(c, axis=0).T))]
n = int(L[-1] * 2)  # 2 samples per source px – keeps stitch detail
s = np.linspace(0, L[-1], n)
x = np.interp(s, L, c[:, 0]); y = np.interp(s, L, c[:, 1])
tx = np.gradient(x); ty = np.gradient(y); l = np.hypot(tx, ty); nx, ny = -ty / l, tx / l
rows = int(hh * 2 * 2)
v = np.linspace(-hh, hh, rows) + off
mapx = (x[None, :] + nx[None, :] * v[:, None]).astype(np.float32)
mapy = (y[None, :] + ny[None, :] * v[:, None]).astype(np.float32)
band = cv2.remap(im, mapx, mapy, cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
# soft top/bottom edges so the strip reads as a lifted thread bundle, not a cut rectangle
e = np.clip(np.minimum(np.arange(rows), rows - 1 - np.arange(rows)) / (rows * 0.18), 0, 1)
band[..., 3] *= e[:, None]
cv2.imwrite(out, np.clip(band, 0, 255).astype(np.uint8))
print(out, band.shape)
