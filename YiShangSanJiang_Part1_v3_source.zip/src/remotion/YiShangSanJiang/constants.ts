// 衣上三江 — Part 1 shared constants.
export const PART1_ID = "YiShangSanJiang-Part1";
export const W = 1920;
export const H = 1080;
export const FPS = 30;
export const PART1_FRAMES = 42 * FPS; // 1260

// Shot boundaries (frames) – revision 2 (42 s)
export const SHOT = {
  intro: [0, 150], // museum introduction
  garment: [150, 390], // garment identification
  rivers: [390, 630], // the three rivers explained
  awaken: [630, 870], // embroidery awakens
  becomeRiver: [870, 1080], // embroidery becomes the Yellow River
  journey: [1080, 1260], // Yellow River journey → hand-off to Part 2
} as const;

export const PALETTE = {
  charcoal: "#141416",
  charcoalLift: "#25242a",
  indigoDeep: "#0e1424",
  indigo: "#1b2644",
  indigoMid: "#2c3e6b",
  indigoBlue: "#4d6aa8",
  ivory: "#efe4c9",
  ivoryWarm: "#f6e7c1",
  gold: "#c9a45c",
  goldDeep: "#a9813d",
  ochre: "#c4873f",
  ochreLight: "#dcab63",
  terracotta: "#a2553a",
  sand: "#dcb47b",
  earth: "#5d3b25",
  ground: "#7a5131",
  shadow: "#2a170c",
};
