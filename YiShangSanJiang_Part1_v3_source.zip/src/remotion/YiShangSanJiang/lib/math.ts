// Deterministic geometry + timing helpers shared by every module of 衣上三江.

export type Pt = { x: number; y: number };

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (t: number) => {
  const c = clamp(t);
  return c * c * (3 - 2 * c);
};
// cinematic ease-in-out (slower shoulders than smoothstep)
export const easeInOut = (t: number) => {
  const c = clamp(t);
  return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
};
export const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
export const easeIn = (t: number) => Math.pow(clamp(t), 3);

/** progress of `frame` through [start,end], clamped, optionally eased */
export const prog = (frame: number, start: number, end: number, ease: (t: number) => number = (t) => t) =>
  ease(clamp((frame - start) / (end - start)));

/** Keyframed scalar/vector track with per-segment easing. */
export type Key<T> = { f: number; v: T; ease?: (t: number) => number };
export function track(frame: number, keys: Key<number>[]): number {
  if (frame <= keys[0].f) return keys[0].v;
  for (let i = 1; i < keys.length; i++) {
    if (frame <= keys[i].f) {
      const a = keys[i - 1];
      const b = keys[i];
      const t = (b.ease ?? easeInOut)((frame - a.f) / (b.f - a.f));
      return lerp(a.v, b.v, t);
    }
  }
  return keys[keys.length - 1].v;
}

export const mixHex = (a: string, b: string, t: number) => {
  const pa = parseInt(a.slice(1), 16);
  const pb = parseInt(b.slice(1), 16);
  const c = (s: number) => [(s >> 16) & 255, (s >> 8) & 255, s & 255];
  const [r1, g1, b1] = c(pa);
  const [r2, g2, b2] = c(pb);
  const k = clamp(t);
  const h = (v: number) => Math.round(v).toString(16).padStart(2, "0");
  return `#${h(lerp(r1, r2, k))}${h(lerp(g1, g2, k))}${h(lerp(b1, b2, k))}`;
};

/** mulberry32 seeded PRNG */
export const rng = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

/** Catmull-Rom spline through control points, `seg` samples per span. */
export function catmull(pts: Pt[], seg = 24): Pt[] {
  const out: Pt[] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[Math.min(pts.length - 1, i + 2)];
    for (let j = 0; j < seg; j++) {
      const t = j / seg;
      const t2 = t * t;
      const t3 = t2 * t;
      const f = (a: number, b: number, c: number, d: number) =>
        0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
      out.push({ x: f(p0.x, p1.x, p2.x, p3.x), y: f(p0.y, p1.y, p2.y, p3.y) });
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}

export const dist = (a: Pt, b: Pt) => Math.hypot(a.x - b.x, a.y - b.y);

export function cumLength(pts: Pt[]): number[] {
  const L = [0];
  for (let i = 1; i < pts.length; i++) L.push(L[i - 1] + dist(pts[i - 1], pts[i]));
  return L;
}

/** point at arc length s */
export function pointAt(pts: Pt[], L: number[], s: number): Pt {
  if (s <= 0) return pts[0];
  const total = L[L.length - 1];
  if (s >= total) return pts[pts.length - 1];
  let lo = 0;
  let hi = L.length - 1;
  while (hi - lo > 1) {
    const m = (lo + hi) >> 1;
    if (L[m] < s) lo = m;
    else hi = m;
  }
  const t = (s - L[lo]) / (L[hi] - L[lo] || 1);
  return { x: lerp(pts[lo].x, pts[hi].x, t), y: lerp(pts[lo].y, pts[hi].y, t) };
}

/** resample polyline into n points evenly spaced between arc lengths s0..s1 */
export function resample(pts: Pt[], n: number, s0 = 0, s1?: number): Pt[] {
  const L = cumLength(pts);
  const end = s1 ?? L[L.length - 1];
  const out: Pt[] = [];
  for (let i = 0; i < n; i++) out.push(pointAt(pts, L, lerp(s0, end, i / (n - 1))));
  return out;
}

export function normals(pts: Pt[]): Pt[] {
  return pts.map((_, i) => {
    const a = pts[Math.max(0, i - 1)];
    const b = pts[Math.min(pts.length - 1, i + 1)];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const l = Math.hypot(dx, dy) || 1;
    return { x: -dy / l, y: dx / l };
  });
}

/** offset polyline by per-point distance */
export function offset(pts: Pt[], nrm: Pt[], d: (i: number) => number): Pt[] {
  return pts.map((p, i) => ({ x: p.x + nrm[i].x * d(i), y: p.y + nrm[i].y * d(i) }));
}

export const toD = (pts: Pt[], close = false) => {
  if (!pts.length) return "";
  let s = `M${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
  for (let i = 1; i < pts.length; i++) s += `L${pts[i].x.toFixed(1)} ${pts[i].y.toFixed(1)}`;
  return close ? s + "Z" : s;
};

/** Smooth path (quadratic midpoints) – softer than straight polyline for organic shapes. */
export const toSmoothD = (pts: Pt[], close = false) => {
  const n = pts.length;
  if (n < 3) return toD(pts, close);
  const mid = (a: Pt, b: Pt) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
  const f = (v: number) => v.toFixed(1);
  if (close) {
    const m0 = mid(pts[n - 1], pts[0]);
    let s = `M${f(m0.x)} ${f(m0.y)}`;
    for (let i = 0; i < n; i++) {
      const p = pts[i];
      const m = mid(p, pts[(i + 1) % n]);
      s += `Q${f(p.x)} ${f(p.y)} ${f(m.x)} ${f(m.y)}`;
    }
    return s + "Z";
  }
  let s = `M${f(pts[0].x)} ${f(pts[0].y)}`;
  for (let i = 1; i < n - 1; i++) {
    const m = mid(pts[i], pts[i + 1]);
    s += `Q${f(pts[i].x)} ${f(pts[i].y)} ${f(m.x)} ${f(m.y)}`;
  }
  s += `L${f(pts[n - 1].x)} ${f(pts[n - 1].y)}`;
  return s;
};

/**
 * Smooth camera track: monotone cubic Hermite through (frame, value) keys.
 * Velocity is continuous across keys (no stop-start), zero at first/last key.
 */
export function spline(frame: number, keys: [number, number][]): number {
  const n = keys.length;
  if (frame <= keys[0][0]) return keys[0][1];
  if (frame >= keys[n - 1][0]) return keys[n - 1][1];
  const d: number[] = [];
  for (let i = 0; i < n - 1; i++) d.push((keys[i + 1][1] - keys[i][1]) / (keys[i + 1][0] - keys[i][0]));
  const m: number[] = keys.map((_, i) => {
    if (i === 0 || i === n - 1) return 0;
    if (d[i - 1] * d[i] <= 0) return 0;
    return (2 * d[i - 1] * d[i]) / (d[i - 1] + d[i]); // harmonic mean keeps it monotone
  });
  let i = 0;
  while (frame > keys[i + 1][0]) i++;
  const [x0, y0] = keys[i];
  const [x1, y1] = keys[i + 1];
  const h = x1 - x0;
  const t = (frame - x0) / h;
  const t2 = t * t;
  const t3 = t2 * t;
  return (2 * t3 - 3 * t2 + 1) * y0 + (t3 - 2 * t2 + t) * h * m[i] + (-2 * t3 + 3 * t2) * y1 + (t3 - t2) * h * m[i + 1];
}
