// Canvas texture-mapping of a real embroidered strip (unwrapped from the photo) along any path.
// Slices of the source band are drawn rotated to the path tangent, so stitches, fibres and the
// original colours travel with the shape as it bends into the river.
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import { continueRender, delayRender, staticFile } from "remotion";
import { H, W } from "../constants";
import type { Pt } from "../lib/math";

const SRC = staticFile("yssj/hem_band.png");

export const EmbroideryBand: React.FC<{
  pts: Pt[]; // centreline, screen px
  thickness: number[]; // per point, screen px
  opacity: number;
  lift: number; // shadow distance
}> = ({ pts, thickness, opacity, lift }) => {
  const ref = useRef<HTMLCanvasElement>(null);
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [handle] = useState(() => delayRender("embroidery band"));
  useEffect(() => {
    const i = new Image();
    i.onload = () => {
      setImg(i);
      continueRender(handle);
    };
    i.onerror = () => continueRender(handle);
    i.src = SRC;
  }, [handle]);

  useLayoutEffect(() => {
    const cv = ref.current;
    if (!cv || !img) return;
    const ctx = cv.getContext("2d")!;
    ctx.clearRect(0, 0, W, H);
    if (opacity <= 0 || pts.length < 2) return;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    const bw = img.width;
    const bh = img.height;
    const n = pts.length - 1;
    const pass = (shadow: boolean) => {
      for (let i = 0; i < n; i++) {
        const a = pts[i];
        const b = pts[i + 1];
        const len = Math.hypot(b.x - a.x, b.y - a.y);
        if (len < 0.01) continue;
        const th = (thickness[i] + thickness[i + 1]) / 2;
        const sx = (i / n) * bw;
        const sw = Math.max(1, bw / n);
        ctx.save();
        ctx.translate(a.x + (shadow ? lift * 0.5 : 0), a.y + (shadow ? lift : 0));
        ctx.rotate(Math.atan2(b.y - a.y, b.x - a.x));
        ctx.drawImage(img, sx, 0, sw, bh, 0, -th / 2, len + 0.9, th);
        ctx.restore();
      }
    };
    if (lift > 0.2) {
      ctx.globalAlpha = opacity * 0.55;
      ctx.filter = `brightness(0) blur(${2 + lift * 0.6}px)`;
      pass(true);
      ctx.filter = "none";
    }
    ctx.globalAlpha = opacity;
    pass(false);
    ctx.globalAlpha = 1;
  }, [img, pts, thickness, opacity, lift]);

  return <canvas ref={ref} width={W} height={H} style={{ position: "absolute", inset: 0 }} />;
};
