// Shots 4–6: the real lower-ribbon embroidery lifts off the hem in its original colours, bends into
// the river's contour (form first), widens into the channel, then hands over to the photographic
// water (colour last). In the final shot a fine thread follows the river onward toward Part 2.
import React from "react";
import { useCurrentFrame } from "remotion";
import { H, W } from "../constants";
import { HEM_STITCH, garmentCam, project } from "../data/garment";
import { RIVER, RIVER_W, landCam, projectLand } from "../data/landscape";
import { clamp, cumLength, easeInOut, lerp, normals, prog, resample, type Pt } from "../lib/math";
import { EmbroideryBand } from "./EmbroideryBand";
import { StitchedRiver } from "./StitchedRiver";

const N = 260;
const BAND_GARMENT_PX = 24 / 1.97; // band height in garment px (24 close-up px)

// resample a polyline and its per-point widths together
const resampleW = (pts: Pt[], w: number[], n: number) => {
  const L = cumLength(pts);
  const total = L[L.length - 1];
  const out: number[] = [];
  let j = 0;
  for (let i = 0; i < n; i++) {
    const s = (i / (n - 1)) * total;
    while (j < L.length - 2 && L[j + 1] < s) j++;
    const t = clamp((s - L[j]) / (L[j + 1] - L[j] || 1));
    out.push(lerp(w[j], w[j + 1], t));
  }
  return out;
};

// v3: the new bend has hairpins tighter than the channel is wide; cap the widened strip at 1.6× the local
// radius of curvature so the texture slices never fan out on the inside of a bend
const bendCap = (pts: Pt[], k = 3) => {
  const n = pts.length;
  const r = pts.map((_, i) => {
    const a = pts[Math.max(0, i - k)];
    const b = pts[i];
    const c = pts[Math.min(n - 1, i + k)];
    const cross = Math.abs((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x));
    const abc = Math.hypot(b.x - a.x, b.y - a.y) * Math.hypot(c.x - b.x, c.y - b.y) * Math.hypot(c.x - a.x, c.y - a.y);
    return cross < 1e-6 ? 1e6 : abc / (2 * cross);
  });
  // widen each tight spot over its neighbours so the strip narrows smoothly into the bend
  return r.map((_, i) => {
    let m = 1e6;
    for (let j = Math.max(0, i - 2 * k); j <= Math.min(n - 1, i + 2 * k); j++) m = Math.min(m, r[j]);
    return 1.6 * m;
  });
};

const RIVER_FULL_W = RIVER_W.map((w) => w * 1.25);
const RIVER_W_N = resampleW(RIVER, RIVER_FULL_W, N);

export const ThreadJourney: React.FC = () => {
  const f = useCurrentFrame();
  if (f < 636) return null;
  const lc = landCam(f);
  const riverScreen = resample(
    RIVER.map((p) => projectLand(p, lc)),
    N,
  );

  let band: React.ReactNode = null;
  if (f < 992) {
    const gc = garmentCam(f);
    const hem = resample(
      HEM_STITCH.map((p) => project(p, gc)),
      N,
    );
    const hemNrm = normals(hem);
    // 1) awaken: a slow travelling ripple, the strip lifts off the cloth
    const ripple = prog(f, 652, 720, easeInOut) * (1 - prog(f, 800, 860, easeInOut));
    const lift = prog(f, 650, 720, easeInOut);
    const hemLen = cumLength(hem).at(-1)!;
    const awake = hem.map((p, i) => {
      const s = (i / (N - 1)) * hemLen;
      const o = Math.sin(s / 95 - f * 0.11) * 7 * ripple - lift * 5;
      return { x: p.x + hemNrm[i].x * o, y: p.y + hemNrm[i].y * o };
    });
    // 2) form first: bend into the river contour, a wave of change running along the strip
    const M = prog(f, 708, 866, (t) => t);
    const pts = awake.map((p, i) => {
      const m = easeInOut(clamp(M * 1.4 - (i / (N - 1)) * 0.4));
      return { x: lerp(p.x, riverScreen[i].x, m), y: lerp(p.y, riverScreen[i].y, m) };
    });
    // 3) widen into the channel, then 4) give way to the real water
    const base = BAND_GARMENT_PX * gc.z;
    const thin = lerp(base, 26, prog(f, 708, 860, easeInOut));
    const widen = prog(f, 884, 968, easeInOut);
    const cap = bendCap(riverScreen);
    const thickness = RIVER_W_N.map((w, i) => lerp(thin, Math.min(w * lc.z * 0.8, Math.max(thin, cap[i])), widen));
    band = (
      <EmbroideryBand
        pts={pts}
        thickness={thickness}
        opacity={prog(f, 636, 646) * (1 - prog(f, 924, 980, easeInOut))}
        lift={2 + lift * 8 * (1 - widen)}
      />
    );
  }

  // the moving thread that carries on toward the Yangtze (Part 2)
  let thread: React.ReactNode = null;
  if (f >= 1120) {
    const full = RIVER.map((p) => projectLand(p, lc));
    const total = cumLength(full).at(-1)!;
    const head = lerp(0, total * 1.02, prog(f, 1120, 1236, easeInOut));
    const pts = resample(full, 220, 0, Math.min(head, total));
    thread = (
      <StitchedRiver
        id="onward"
        pts={pts}
        widths={pts.map(() => 0)}
        frame={f}
        spread={0}
        water={0}
        bank={0}
        core={0.9 * prog(f, 1120, 1140)}
        lift={2}
        stitchGap={4}
        flowDash={1.2}
        warm="#efe4c9"
        cool="#8fa6dc"
        coolFromX={W * 0.45}
        coolToX={W * 1.05}
      />
    );
  }

  return (
    <div style={{ position: "absolute", inset: 0, width: W, height: H }}>
      {band}
      {thread}
    </div>
  );
};
