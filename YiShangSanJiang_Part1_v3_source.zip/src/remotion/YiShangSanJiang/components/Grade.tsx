// Final grade: fade from black, vignette, and a faint cool wash at the hand-off to Part 2.
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { easeInOut, prog } from "../lib/math";

export const Grade: React.FC = () => {
  const f = useCurrentFrame();
  const black = 1 - prog(f, 0, 18, easeInOut);
  const vignette = 0.5 + 0.12 * prog(f, 1180, 1260, easeInOut);
  const indigo = prog(f, 1176, 1260, easeInOut);
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse 75% 70% at 50% 50%, rgba(0,0,0,0) 58%, rgba(4,4,8,${vignette}) 100%)`,
        }}
      />
      <AbsoluteFill style={{ background: "#14204a", mixBlendMode: "soft-light", opacity: 0.4 * indigo }} />
      <AbsoluteFill style={{ background: "#000", opacity: black }} />
    </AbsoluteFill>
  );
};
