// Museum typography: introduction (shot 1), object identification (shot 2) and the
// three-rivers diagram (shot 3). Text is limited to verified details; the river reading is
// credited as the museum's interpretation and its separators are drawn on the diagram, not the artifact.
import React from "react";
import { staticFile, useCurrentFrame } from "remotion";
import { PALETTE } from "../constants";
import { CLOSEUP, RIBBON_CROP, fromCloseup, garmentCam, project } from "../data/garment";
import { easeInOut, easeOut, prog } from "../lib/math";

export const SERIF = '"Noto Serif SC", "Songti SC", serif';
const CLOSE = staticFile("yssj/skirt_closeup_keyed.png");
const WEAVE = staticFile("yssj/textures/weave.png");

const fadeUp = (f: number, a: number, b: number) => ({
  opacity: prog(f, a, b, easeInOut),
  translate: `0px ${(1 - prog(f, a, b + 10, easeOut)) * 12}px`,
});

/** 0–5 s: quiet introduction of the institution. */
export const MuseumIntro: React.FC = () => {
  const f = useCurrentFrame();
  const out = 1 - prog(f, 118, 146, easeInOut);
  if (out <= 0) return null;
  const rule = prog(f, 14, 70, easeInOut);
  return (
    <div style={{ position: "absolute", inset: 0, fontFamily: SERIF, color: PALETTE.ivory, opacity: out }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `url(${WEAVE})`,
          backgroundSize: "48px",
          mixBlendMode: "overlay",
          opacity: 0.18 * prog(f, 0, 60),
          WebkitMaskImage: "radial-gradient(ellipse 45% 40% at 50% 50%, black 0%, transparent 100%)",
          maskImage: "radial-gradient(ellipse 45% 40% at 50% 50%, black 0%, transparent 100%)",
        }}
      />
      <div style={{ position: "absolute", left: 0, right: 0, top: 418, textAlign: "center", ...fadeUp(f, 22, 58) }}>
        <div style={{ fontSize: 58, letterSpacing: "0.32em", fontWeight: 500, paddingLeft: "0.32em" }}>中央民族大学民族博物馆</div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 960 - 260 * rule,
          width: 520 * rule,
          top: 528,
          height: 1,
          background: `linear-gradient(90deg, transparent, ${PALETTE.gold}, transparent)`,
          opacity: 0.85,
        }}
      />
      <div style={{ position: "absolute", left: 0, right: 0, top: 560, textAlign: "center", ...fadeUp(f, 44, 78) }}>
        <div style={{ fontSize: 26, letterSpacing: "0.2em", opacity: 0.78, paddingLeft: "0.2em" }}>北京 · 海淀区中关村南大街27号</div>
        <div style={{ fontSize: 15, letterSpacing: "0.22em", opacity: 0.42, marginTop: 18, paddingLeft: "0.22em" }}>
          ETHNIC MUSEUM · MINZU UNIVERSITY OF CHINA
        </div>
      </div>
    </div>
  );
};

/** 5–13 s: object identification beside the full garment. */
export const ObjectLabel: React.FC = () => {
  const f = useCurrentFrame();
  const out = 1 - prog(f, 362, 392, easeInOut);
  if (f < 180 || out <= 0) return null;
  return (
    <div style={{ position: "absolute", left: 150, top: 372, fontFamily: SERIF, color: PALETTE.ivory, opacity: out }}>
      <div style={{ width: 36, height: 1, background: PALETTE.gold, marginBottom: 30, opacity: prog(f, 186, 214) }} />
      <div style={{ fontSize: 56, letterSpacing: "0.2em", fontWeight: 500, ...fadeUp(f, 194, 226) }}>绣花盛装女服</div>
      <div style={{ fontSize: 28, letterSpacing: "0.16em", marginTop: 26, ...fadeUp(f, 214, 246), opacity: 0.85 * prog(f, 214, 246) }}>
        苗族 · 贵州台江 · 20世纪80年代
      </div>
      <div style={{ fontSize: 22, letterSpacing: "0.14em", marginTop: 16, ...fadeUp(f, 232, 264), opacity: 0.6 * prog(f, 232, 264) }}>
        中央民族大学民族博物馆馆藏
      </div>
      <div style={{ fontSize: 14, letterSpacing: "0.1em", marginTop: 26, maxWidth: 520, lineHeight: 1.7, opacity: 0.38 * prog(f, 256, 290) }}>
        Embroidered ceremonial garment for women · Miao · Taijiang, Guizhou · 1980s
      </div>
    </div>
  );
};

const SECTIONS = [
  { cn: "上段：清水江", en: "Upper section · Qingshui River" },
  { cn: "中段：长江", en: "Middle section · Yangtze River" },
  { cn: "下段：黄河", en: "Lower section · Yellow River" },
];

/** 13–21 s: interpretive diagram – an enlarged real ribbon column with two separator lines beside it. */
export const RiversDiagram: React.FC = () => {
  const f = useCurrentFrame();
  const out = 1 - prog(f, 598, 628, easeInOut);
  if (f < 440 || out <= 0) return null;
  const k = 600 / RIBBON_CROP.h;
  const sx = 1268;
  const sy = 236;
  const sw = RIBBON_CROP.w * k;
  const sh = RIBBON_CROP.h * k;
  const y1 = sy + (RIBBON_CROP.upperMid - RIBBON_CROP.y) * k;
  const y2 = sy + (RIBBON_CROP.midLower - RIBBON_CROP.y) * k;
  const zones = [
    [sy, y1],
    [y1, y2],
    [y2, sy + sh],
  ];
  const lineX0 = sx + sw + 22;
  const lineX1 = 1830;
  const strip = prog(f, 448, 484, easeInOut);
  const lines = prog(f, 470, 512, easeInOut);
  // callout on the garment: where the enlarged column comes from (an outline, not a seam)
  const cam = garmentCam(f);
  const a = project(fromCloseup(RIBBON_CROP.x, RIBBON_CROP.y), cam);
  const b = project(fromCloseup(RIBBON_CROP.x + RIBBON_CROP.w, RIBBON_CROP.y + RIBBON_CROP.h), cam);
  return (
    <div style={{ position: "absolute", inset: 0, fontFamily: SERIF, color: PALETTE.ivory, opacity: out }}>
      <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
        <rect
          x={a.x - 4}
          y={a.y - 4}
          width={b.x - a.x + 8}
          height={b.y - a.y + 8}
          fill="none"
          stroke={PALETTE.ivory}
          strokeWidth={1}
          strokeDasharray="3 5"
          opacity={0.5 * strip}
        />
        {[y1, y2].map((y, i) => (
          <line key={i} x1={lineX0} x2={lineX0 + (lineX1 - lineX0) * lines} y1={y} y2={y} stroke={PALETTE.ivory} strokeWidth={1} opacity={0.55} />
        ))}
        <line x1={lineX0} x2={lineX0} y1={sy} y2={sy + sh * lines} stroke={PALETTE.ivory} strokeWidth={1} opacity={0.22} />
      </svg>
      <div style={{ position: "absolute", left: sx, top: sy - 46, fontSize: 14, letterSpacing: "0.16em", opacity: 0.5 * strip }}>
        飘带局部 · ribbon detail
      </div>
      <div
        style={{
          position: "absolute",
          left: sx,
          top: sy,
          width: sw,
          height: sh,
          opacity: strip,
          backgroundImage: `url(${CLOSE})`,
          backgroundSize: `${CLOSEUP.w * k}px ${CLOSEUP.h * k}px`,
          backgroundPosition: `${-RIBBON_CROP.x * k}px ${-RIBBON_CROP.y * k}px`,
          boxShadow: "0 18px 40px rgba(0,0,0,0.55)",
          outline: "1px solid rgba(239,228,201,0.18)",
          clipPath: `inset(0 0 ${(1 - strip) * 100}% 0)`,
        }}
      />
      {SECTIONS.map((s, i) => {
        const [z0, z1] = zones[i];
        const t0 = 492 + i * 12;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: lineX0 + 34,
              top: (z0 + z1) / 2 - 38,
              color: i === 2 ? "#e6c98c" : PALETTE.ivory,
              ...fadeUp(f, t0, t0 + 26),
            }}
          >
            <div style={{ fontSize: 40, letterSpacing: "0.12em", fontWeight: 500 }}>{s.cn}</div>
            <div style={{ fontSize: 15, letterSpacing: "0.12em", opacity: 0.55, marginTop: 8 }}>{s.en}</div>
          </div>
        );
      })}
      <div style={{ position: "absolute", left: sx, top: sy + sh + 34, fontSize: 16, letterSpacing: "0.14em", opacity: 0.55 * prog(f, 532, 560) }}>
        据中央民族大学民族博物馆馆藏释义
      </div>
    </div>
  );
};
