// One renderer for the whole metamorphosis: a single embroidery thread → a bundle of strands →
// a satin-stitched river with a floodplain → back to a thread. Shots 3–6 all draw through this.
import React from "react";
import { PALETTE } from "../constants";
import { clamp, normals, offset, toSmoothD, type Pt } from "../lib/math";

export type RibbonProps = {
  id: string;
  pts: Pt[]; // centreline, screen px
  widths: number[]; // water width per point, screen px
  frame: number;
  baseIndex?: number; // global sample index of pts[0] – keeps satin stitches anchored in the world
  spread: number; // 0 = strands bundled into one thread, 1 = strands sit on the banks
  water: number; // water body opacity
  bank: number; // floodplain opacity
  core: number; // single-thread opacity
  stitchGap?: number; // running-stitch gap (px) while the thread is still sewn into cloth
  lift?: number; // shadow distance – thread lifting off the fabric
  warm?: string; // thread colour (warm end)
  cool?: string; // thread colour (cool end) – used past coolFromX
  coolFromX?: number; // screen x where the indigo shift begins
  coolToX?: number;
  waterColor?: string;
  bankColor?: string;
  head?: number; // 0..1 glint at the moving head
  flowDash?: number; // px/frame the running stitch travels along the path
};

const hash = (i: number) => {
  const s = Math.sin(i * 127.1) * 43758.5453;
  return s - Math.floor(s);
};

export const StitchedRiver: React.FC<RibbonProps> = ({
  id,
  pts,
  widths,
  frame,
  baseIndex = 0,
  spread,
  water,
  bank,
  core,
  stitchGap = 0,
  lift = 0,
  warm = PALETTE.gold,
  cool,
  coolFromX = 99999,
  coolToX = 99999,
  waterColor = PALETTE.ochre,
  bankColor = "#b88a55",
  head = 0,
  flowDash = 0,
}) => {
  if (pts.length < 2) return null;
  const nrm = normals(pts);
  const half = (i: number) => widths[i] / 2;
  const left = offset(pts, nrm, half);
  const right = offset(pts, nrm, (i) => -half(i));
  const body = toSmoothD([...left, ...[...right].reverse()], true);
  const bankL = offset(pts, nrm, (i) => half(i) * 2.1 + 6);
  const bankR = offset(pts, nrm, (i) => -half(i) * 2.1 - 6);
  const bankD = toSmoothD([...bankL, ...[...bankR].reverse()], true);

  // satin stitches across the water, slanted, anchored to world sample index
  let satin = "";
  let satinDark = "";
  if (water > 0.01) {
    for (let i = 1; i < pts.length - 1; i++) {
      const g = baseIndex + i;
      const w = half(i) * 0.94;
      if (w < 2) continue;
      const tx = -nrm[i].y;
      const ty = nrm[i].x;
      const slant = w * 0.55 * (0.8 + hash(g) * 0.4);
      const a = { x: pts[i].x + nrm[i].x * w - tx * slant, y: pts[i].y + nrm[i].y * w - ty * slant };
      const b = { x: pts[i].x - nrm[i].x * w + tx * slant, y: pts[i].y - nrm[i].y * w + ty * slant };
      const seg = `M${a.x.toFixed(1)} ${a.y.toFixed(1)}L${b.x.toFixed(1)} ${b.y.toFixed(1)}`;
      if (g % 2 === 0) satin += seg;
      else satinDark += seg;
    }
  }

  const strandOffsets = [-1, -0.55, 0.55, 1];
  const grad = cool ? `url(#${id}-thread)` : warm;
  const shadowD = toSmoothD(pts.map((p) => ({ x: p.x + lift * 0.6, y: p.y + lift })));
  const coreD = toSmoothD(pts);
  const flow = (k: number) => toSmoothD(offset(pts, nrm, (i) => half(i) * k));
  const h = pts[pts.length - 1];

  return (
    <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, overflow: "visible" }}>
      <defs>
        {cool ? (
          <linearGradient id={`${id}-thread`} gradientUnits="userSpaceOnUse" x1={coolFromX} x2={coolToX} y1={0} y2={0}>
            <stop offset="0" stopColor={warm} />
            <stop offset="1" stopColor={cool} />
          </linearGradient>
        ) : null}
        <radialGradient id={`${id}-glint`}>
          <stop offset="0" stopColor="#fff6dd" stopOpacity="0.95" />
          <stop offset="0.35" stopColor={PALETTE.ivoryWarm} stopOpacity="0.45" />
          <stop offset="1" stopColor={PALETTE.ivoryWarm} stopOpacity="0" />
        </radialGradient>
      </defs>

      {bank > 0.01 ? <path d={bankD} fill={bankColor} opacity={bank} /> : null}
      {bank > 0.01 ? <path d={bankD} fill="none" stroke="#3b2414" strokeOpacity={0.25 * bank} strokeWidth={1.2} /> : null}

      {water > 0.01 ? (
        <g opacity={water}>
          <path d={body} fill={waterColor} />
          <path d={satin} stroke="#e9bf78" strokeWidth={1.25} opacity={0.42} />
          <path d={satinDark} stroke="#8e5b2a" strokeWidth={1.1} opacity={0.32} />
          {[-0.45, 0, 0.42].map((k, i) => (
            <path
              key={i}
              d={flow(k)}
              fill="none"
              stroke="#f2d39b"
              strokeWidth={1.1}
              strokeDasharray={`${34 + i * 9} ${46 + i * 13}`}
              strokeDashoffset={-frame * (1.6 + i * 0.35)}
              opacity={0.35}
            />
          ))}
          <path d={body} fill="none" stroke="#5a3415" strokeOpacity={0.35} strokeWidth={1} />
        </g>
      ) : null}

      {/* edge strands – the thread stays perceptible on the banks */}
      {spread > 0.001
        ? strandOffsets.map((k, i) => {
            const d = toSmoothD(offset(pts, nrm, (j) => half(j) * k * spread));
            const outer = Math.abs(k) === 1;
            return (
              <g key={i}>
                <path d={d} fill="none" stroke="#1a0f08" strokeOpacity={0.35} strokeWidth={2.2} transform="translate(0.8 1.4)" />
                <path
                  d={d}
                  fill="none"
                  stroke={grad}
                  strokeWidth={outer ? 1.9 : 1.4}
                  strokeLinecap="round"
                  strokeDasharray={outer ? `${9} ${3.5 * clamp(spread * 1.4)}` : undefined}
                  opacity={outer ? 0.95 : 0.75 * clamp(1.6 - water * 1.6)}
                />
              </g>
            );
          })
        : null}

      {core > 0.01 ? (
        <g opacity={core}>
          <path d={shadowD} fill="none" stroke="#000" strokeOpacity={0.45} strokeWidth={3.2} strokeLinecap="round" strokeDasharray={stitchGap ? `9 ${stitchGap}` : undefined} strokeDashoffset={-frame * flowDash} />
          <path d={coreD} fill="none" stroke={grad} strokeWidth={2.4} strokeLinecap="round" strokeDasharray={stitchGap ? `9 ${stitchGap}` : undefined} strokeDashoffset={-frame * flowDash} />
          {/* plied highlight – the twist of a silk thread */}
          <path d={coreD} fill="none" stroke="#fff3d6" strokeWidth={1} strokeOpacity={0.75} strokeDasharray="2.2 3.4" strokeDashoffset={-frame * 0.5} />
        </g>
      ) : null}

      {head > 0.01 ? <circle cx={h.x} cy={h.y} r={10} fill={`url(#${id}-glint)`} opacity={head} /> : null}
    </svg>
  );
};

