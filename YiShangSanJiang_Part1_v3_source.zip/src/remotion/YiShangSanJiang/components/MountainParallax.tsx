// Photo-guided 2.5D Yellow River terrain (shots 5–6).
// Layers: distant haze / main terrain / water / foreground hills, each with its own parallax.
// The terrain grows outward from the river through a distance-field mask (relief first, colour after),
// over a dark woven-cloth field so the garment → landscape change is continuous.
import React from "react";
import { staticFile } from "remotion";
import { H, W } from "../constants";
import type { Cam } from "../data/garment";
import { PHOTO, RIVER, RIVER_W, landCam, layerCam, projectLand } from "../data/landscape";
import { easeInOut, normals, offset, prog, toSmoothD, track } from "../lib/math";

const L = (n: string) => staticFile(`yssj/landscape/${n}`);
const PAPER = staticFile("yssj/textures/paper_grain.png");
const WEAVE = staticFile("yssj/textures/weave.png");

const rect = (c: Cam) => ({
  x: W / 2 - c.cx * c.z,
  y: H / 2 - c.cy * c.z,
  width: PHOTO.w * c.z,
  height: PHOTO.h * c.z,
});

/** distance-field threshold filter → luminance mask that grows from the river centreline */
const Threshold: React.FC<{ id: string; r: number; soft: number }> = ({ id, r, soft }) => {
  const slope = -1 / soft;
  const icpt = r / soft;
  return (
    <filter id={id} colorInterpolationFilters="sRGB" x="0" y="0" width="1" height="1">
      <feComponentTransfer>
        <feFuncR type="linear" slope={slope} intercept={icpt} />
        <feFuncG type="linear" slope={slope} intercept={icpt} />
        <feFuncB type="linear" slope={slope} intercept={icpt} />
      </feComponentTransfer>
    </filter>
  );
};

export const terrainReveal = (f: number) => track(f, [{ f: 912, v: 0 }, { f: 1050, v: 1.75, ease: (t) => t * t * (3 - 2 * t) }]);
export const riverReveal = (f: number) => track(f, [{ f: 884, v: 0 }, { f: 968, v: 0.17 }]);

export const Terrain: React.FC<{ frame: number }> = ({ frame: f }) => {
  const c = landCam(f);
  const far = rect(layerCam(c, 0.55));
  const main = rect(c);
  const near = rect(layerCam(c, 1.4));
  const relief = 1 - prog(f, 968, 1068, easeInOut); // 1 = monochrome relief, 0 = natural colour
  const waterTint = 1 - prog(f, 930, 1040, easeInOut);
  const cloth = prog(f, 780, 880, easeInOut);
  const rT = terrainReveal(f);
  const rR = riverReveal(f);

  // flow lines along the real centreline
  const pts = RIVER.map((p) => projectLand(p, c));
  const nrm = normals(pts);
  const flow = [-0.42, -0.12, 0.2, 0.5].map((k) => toSmoothD(offset(pts, nrm, (i) => RIVER_W[i] * 0.62 * c.z * k)));
  const flowOn = prog(f, 960, 1040, easeInOut);

  const tile = 512 * c.z * 0.6;
  const ox = -((c.cx * c.z) % tile);
  const oy = -((c.cy * c.z) % tile);

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      {/* dark woven cloth – the garment's ground – that the plateau grows out of */}
      <div style={{ position: "absolute", inset: 0, opacity: cloth }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse 90% 80% at 50% 55%, #241a1d 0%, #120e12 100%)" }} />
        <div style={{ position: "absolute", inset: 0, backgroundImage: `url(${WEAVE})`, backgroundSize: "54px", mixBlendMode: "overlay", opacity: 0.5 }} />
      </div>
      <svg width={W} height={H} style={{ position: "absolute", inset: 0 }}>
        <defs>
          {rT < 1.74 ? <Threshold id="thrT" r={rT} soft={0.2} /> : null}
          {waterTint > 0.001 ? <Threshold id="thrR" r={rR} soft={0.035} /> : null}
          {rT < 1.74 ? (
            <mask id="mT" maskUnits="userSpaceOnUse" x={0} y={0} width={W} height={H}>
              <image href={L("dist.png")} {...main} preserveAspectRatio="none" filter="url(#thrT)" />
            </mask>
          ) : null}
          {waterTint > 0.001 ? (
            <mask id="mR" maskUnits="userSpaceOnUse" x={0} y={0} width={W} height={H}>
              <image href={L("dist.png")} {...main} preserveAspectRatio="none" filter="url(#thrR)" />
            </mask>
          ) : null}
          <mask id="mWater" maskUnits="userSpaceOnUse" x={0} y={0} width={W} height={H} style={{ maskType: "alpha" }}>
            <image href={L("river.png")} {...main} preserveAspectRatio="none" />
          </mask>
        </defs>
        {rT > 0.001 ? (
          <g
            mask={rT < 1.74 ? "url(#mT)" : undefined}
            style={{
              filter:
                relief > 0.001
                  ? `grayscale(${0.92 * relief}) sepia(${0.38 * relief}) contrast(${1 + 0.2 * relief}) brightness(${1 - 0.14 * relief})`
                  : undefined,
            }}
          >
            <image href={L("far.jpg")} {...far} preserveAspectRatio="none" />
            <image href={L("main.png")} {...main} preserveAspectRatio="none" />
            <image href={L("near.png")} {...near} preserveAspectRatio="none" />
          </g>
        ) : null}
        {rR > 0.001 && waterTint > 0.001 ? (
          <g mask="url(#mR)" style={{ filter: `hue-rotate(${-24 * waterTint}deg) saturate(${1 + 0.55 * waterTint}) brightness(${1 - 0.1 * waterTint})` }}>
            <image href={L("river.png")} {...main} preserveAspectRatio="none" />
          </g>
        ) : null}
        {flowOn > 0 ? (
          <g mask="url(#mWater)" opacity={flowOn}>
            {flow.map((d, i) => (
              <path
                key={i}
                d={d}
                fill="none"
                stroke="#fff1d6"
                strokeWidth={1.3}
                strokeLinecap="round"
                strokeDasharray={`${18 + i * 7} ${54 + i * 15}`}
                strokeDashoffset={-f * (1.2 + i * 0.22)}
                opacity={0.2}
              />
            ))}
          </g>
        ) : null}
      </svg>
      {/* atmospheric depth: slow drifting haze in the sunlit distance */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: prog(f, 1000, 1080, easeInOut) * 0.55,
          background: `radial-gradient(ellipse 38% 30% at ${62 + Math.sin(f / 70) * 2}% ${16 + (f - 1000) * 0.006}%, rgba(255,240,214,0.55) 0%, rgba(255,240,214,0) 100%)`,
          mixBlendMode: "screen",
        }}
      />
      {/* woven-paper texture links the land back to the cloth */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `url(${PAPER})`,
          backgroundSize: `${tile}px ${tile}px`,
          backgroundPosition: `${ox}px ${oy}px`,
          mixBlendMode: "overlay",
          opacity: 0.32 * prog(f, 900, 1000),
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `url(${WEAVE})`,
          backgroundSize: `${60 * c.z * 0.5}px`,
          backgroundPosition: `${ox}px ${oy}px`,
          mixBlendMode: "soft-light",
          opacity: 0.22 * prog(f, 900, 1000),
        }}
      />
    </div>
  );
};
