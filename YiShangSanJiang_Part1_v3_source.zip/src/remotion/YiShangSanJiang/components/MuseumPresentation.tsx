// Shots 1–4: the real garment under a museum spotlight, the push-in to the ribbon skirt,
// depth-of-field, fibre detail and the three-part section reveal.
import React from "react";
import { AbsoluteFill, Img, staticFile, useCurrentFrame } from "remotion";
import { H, PALETTE, W } from "../constants";
import { CLOSEUP, GARMENT_IMG, garmentCam } from "../data/garment";
import { easeInOut, prog, track } from "../lib/math";

const FULL = staticFile("yssj/garment_full_keyed.png");
const CLOSE = staticFile("yssj/skirt_closeup_keyed.png");
const WEAVE = staticFile("yssj/textures/weave.png");

/** Spotlight intensity 0..1 (shot 1 awakening) */
export const spotlight = (f: number) => prog(f, 128, 222, easeInOut);
/** Overall garment visibility (fades as the thread leaves for the river) */
export const garmentPresence = (f: number) => (f < 120 ? 0 : 1 - prog(f, 790, 900, easeInOut));

export const MuseumPresentation: React.FC = () => {
  const f = useCurrentFrame();
  const cam = garmentCam(f);
  const light = spotlight(f);
  const presence = garmentPresence(f);
  if (presence <= 0.001) return null;

  // stage rectangle (garment px → screen px)
  const left = W / 2 - cam.cx * cam.z;
  const top = H / 2 - cam.cy * cam.z;

  // depth of field: upper garment softens as we push into the skirt
  const dof = track(f, [{ f: 390, v: 0 }, { f: 470, v: 3 }, { f: 630, v: 4 }, { f: 705, v: 7 }, { f: 880, v: 11 }]);
  // sharp focus band on the close-up (in % of close-up height)
  const focusY = track(f, [{ f: 630, v: 55 }, { f: 705, v: 86 }]);
  const focusHalf = track(f, [{ f: 390, v: 160 }, { f: 470, v: 75 }, { f: 630, v: 75 }, { f: 705, v: 22 }]);
  const fibre = track(f, [{ f: 400, v: 0 }, { f: 470, v: 0.08 }, { f: 640, v: 0.08 }, { f: 720, v: 0.16 }]);
  const sheenX = track(f, [{ f: 640, v: -40 }, { f: 820, v: 140 }]);
  const exposure = (0.04 + 0.96 * light) * (1 - 0.4 * prog(f, 720, 860, easeInOut));

  const closeStyle: React.CSSProperties = {
    position: "absolute",
    left: CLOSEUP.ox * cam.z,
    top: CLOSEUP.oy * cam.z,
    width: CLOSEUP.w * CLOSEUP.scale * cam.z,
    height: CLOSEUP.h * CLOSEUP.scale * cam.z,
  };
  const maskAlpha = {
    WebkitMaskImage: `url(${CLOSE})`,
    WebkitMaskSize: "100% 100%",
    maskImage: `url(${CLOSE})`,
    maskSize: "100% 100%",
  } as React.CSSProperties;

  return (
    <AbsoluteFill style={{ opacity: presence }}>
      {/* soft pool of light on the exhibition wall */}
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse ${0.5 * GARMENT_IMG.w * cam.z * 1.5}px ${0.5 * GARMENT_IMG.h * cam.z * 1.25}px at ${W / 2 + (300 - cam.cx) * cam.z}px ${H / 2 + (330 - cam.cy) * cam.z}px, ${PALETTE.charcoalLift} 0%, rgba(20,20,22,0) 100%)`,
          opacity: light,
        }}
      />
      <div
        style={{
          position: "absolute",
          left,
          top,
          width: GARMENT_IMG.w * cam.z,
          height: GARMENT_IMG.h * cam.z,
          filter: `brightness(${exposure})`,
        }}
      >
        <Img
          src={FULL}
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            filter: `blur(${dof}px) drop-shadow(0px ${14 * cam.z}px ${18 * cam.z}px rgba(0,0,0,0.55))`,
          }}
        />
        {/* close-up photo registered onto the full garment: blurred base + sharp focus band */}
        <div
          style={{
            ...closeStyle,
            WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 9%)",
            maskImage: "linear-gradient(to bottom, transparent 0%, black 9%)",
          }}
        >
          <Img src={CLOSE} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", filter: `blur(${dof * 0.55}px)` }} />
          <Img
            src={CLOSE}
            style={{
              position: "absolute",
              inset: 0,
              width: "100%",
              height: "100%",
              WebkitMaskImage: `linear-gradient(to bottom, transparent ${focusY - focusHalf - 14}%, black ${focusY - focusHalf}%, black ${focusY + focusHalf}%, transparent ${focusY + focusHalf + 14}%)`,
              maskImage: `linear-gradient(to bottom, transparent ${focusY - focusHalf - 14}%, black ${focusY - focusHalf}%, black ${focusY + focusHalf}%, transparent ${focusY + focusHalf + 14}%)`,
            }}
          />
          {/* woven fibre relief, only where there is cloth */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              ...maskAlpha,
              backgroundImage: `url(${WEAVE})`,
              backgroundSize: `${192 * cam.z * 0.16}px`,
              mixBlendMode: "overlay",
              opacity: fibre,
            }}
          />
          {/* raking light sweeping across the embroidery */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              ...maskAlpha,
              background: `linear-gradient(105deg, transparent ${sheenX - 22}%, rgba(255,236,200,0.55) ${sheenX}%, transparent ${sheenX + 22}%)`,
              mixBlendMode: "soft-light",
              opacity: prog(f, 640, 680) * (1 - prog(f, 790, 830)),
            }}
          />
        </div>
      </div>
    </AbsoluteFill>
  );
};
