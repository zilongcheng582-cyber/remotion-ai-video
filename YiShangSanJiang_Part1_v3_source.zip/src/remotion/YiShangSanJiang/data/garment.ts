// Measurements of the museum garment, in pixel coordinates of the full-garment photo (600×695).
// The close-up photo maps onto it at 1/1.97 scale, offset (1, 304) – found by image registration.
import { catmull, spline, type Pt } from "../lib/math";
import { W, H } from "../constants";

export const GARMENT_IMG = { w: 600, h: 695 };
export const CLOSEUP = { w: 1179, h: 699, scale: 1 / 1.97, ox: 1, oy: 304 };

/** close-up pixel → garment coordinate */
export const fromCloseup = (x: number, y: number): Pt => ({
  x: CLOSEUP.ox + x * CLOSEUP.scale,
  y: CLOSEUP.oy + y * CLOSEUP.scale,
});

const arc = (l: [number, number], c: [number, number], r: [number, number]) =>
  catmull(
    [fromCloseup(...l), fromCloseup((l[0] + c[0]) / 2, (l[1] * 0.35 + c[1] * 0.65)), fromCloseup(...c), fromCloseup((r[0] + c[0]) / 2, (r[1] * 0.35 + c[1] * 0.65)), fromCloseup(...r)],
    10,
  );

// Section boundaries traced from the close-up photo (left, centre, right).
export const SECTION_ARCS = {
  top: arc([150, 25], [600, 72], [1010, 25]),
  upperMid: arc([128, 140], [600, 292], [1022, 192]),
  midLower: arc([116, 345], [600, 500], [1030, 408]),
  hem: arc([118, 525], [600, 692], [1022, 585]),
};

export type SectionKey = "upper" | "middle" | "lower";
export const SECTION_BANDS: Record<SectionKey, [Pt[], Pt[]]> = {
  upper: [SECTION_ARCS.top, SECTION_ARCS.upperMid],
  middle: [SECTION_ARCS.upperMid, SECTION_ARCS.midLower],
  lower: [SECTION_ARCS.midLower, SECTION_ARCS.hem],
};

// Running-stitch line along the scalloped lower hem (traced from the alpha contour, close-up px).
const HEM_STITCH_CLOSEUP: [number, number][] = [
  [180, 505], [220, 524], [260, 546], [300, 570], [340, 584], [380, 597], [420, 610], [460, 620],
  [500, 626], [540, 631], [580, 634], [620, 634], [660, 632], [700, 626], [740, 618], [780, 607],
  [820, 596], [860, 586], [900, 571], [940, 557], [975, 545],
];
export const HEM_STITCH: Pt[] = catmull(HEM_STITCH_CLOSEUP.map(([x, y]) => fromCloseup(x, y)), 8);

export type Cam = { cx: number; cy: number; z: number };

/** Camera over the garment (shots 1–4). */
export const garmentCam = (f: number): Cam => ({
  // 150–390 garment sits right of centre (labels on the left); 390–630 skirt on the left half
  // (diagram on the right); 630–870 push into the lower (Yellow River) ribbon.
  cx: spline(f, [[0, 176], [150, 176], [390, 194], [462, 494], [630, 500], [705, 302], [870, 318]]),
  cy: spline(f, [[0, 346], [150, 350], [390, 372], [462, 482], [630, 486], [705, 598], [870, 604]]),
  z: spline(f, [[0, 1.1], [150, 1.12], [390, 1.3], [462, 1.75], [630, 1.84], [705, 3.3], [870, 3.5]]),
});

/** Ribbon column shown enlarged in the three-rivers diagram (close-up px). */
export const RIBBON_CROP = { x: 560, y: 60, w: 100, h: 630, upperMid: 292, midLower: 500 };

export const project = (p: Pt, c: Cam): Pt => ({ x: (p.x - c.cx) * c.z + W / 2, y: (p.y - c.cy) * c.z + H / 2 });
