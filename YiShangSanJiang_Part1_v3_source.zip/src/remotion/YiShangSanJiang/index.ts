// Self-contained entry for rendering 衣上三江 without the template's demo compositions.
// npx remotion render src/remotion/YiShangSanJiang/index.ts YiShangSanJiang-Part1 out.mp4
import { registerRoot } from "remotion";
import { YiShangSanJiangRoot } from "./Root";

registerRoot(YiShangSanJiangRoot);
