// 衣上三江 — Part 1: The Garment and the Yellow River (42 s, 1260 frames @ 30 fps).
import "@fontsource/noto-serif-sc/400.css";
import "@fontsource/noto-serif-sc/500.css";
import React, { useEffect, useState } from "react";
import { AbsoluteFill, Sequence, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Audio } from "@remotion/media";
import { PALETTE, SHOT } from "./constants";
import { MuseumPresentation } from "./components/MuseumPresentation";
import { MuseumIntro, ObjectLabel, RiversDiagram } from "./components/MuseumLabels";
import { ThreadJourney } from "./components/ThreadJourney";
import { Terrain } from "./components/MountainParallax";
import { Grade } from "./components/Grade";

const GLYPHS = "中央民族大学博物馆北京海淀区关村南街27号绣花盛装女服苗族贵州台江世纪80年代藏上段清水长下黄河据释义飘带局部 ETHNICMUSEUMinzu";

const useFonts = () => {
  const [handle] = useState(() => delayRender("Noto Serif SC"));
  useEffect(() => {
    Promise.all([document.fonts.load('400 30px "Noto Serif SC"', GLYPHS), document.fonts.load('500 30px "Noto Serif SC"', GLYPHS)])
      .catch(() => undefined)
      .then(() => continueRender(handle));
  }, [handle]);
};

const Landscape: React.FC = () => {
  const f = useCurrentFrame();
  if (f < 770) return null;
  return <Terrain frame={f} />;
};

export const YiShangSanJiangPart1: React.FC = () => {
  useFonts();
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{ backgroundColor: PALETTE.charcoal }}>
      <Landscape />
      <MuseumPresentation />
      <ThreadJourney />
      <MuseumIntro />
      <ObjectLabel />
      <RiversDiagram />
      <Grade />
      <Sequence name="Ambient score" from={SHOT.intro[0]} premountFor={fps}>
        <Audio src={staticFile("yssj/audio/part1_ambient.wav")} />
      </Sequence>
    </AbsoluteFill>
  );
};
