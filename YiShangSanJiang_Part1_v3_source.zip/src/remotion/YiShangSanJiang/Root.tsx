import React from "react";
import { Composition } from "remotion";
import { FPS, H, PART1_FRAMES, PART1_ID, W } from "./constants";
import { YiShangSanJiangPart1 } from "./YiShangSanJiang_Part1";

export const YiShangSanJiangRoot: React.FC = () => (
  <Composition id={PART1_ID} component={YiShangSanJiangPart1} durationInFrames={PART1_FRAMES} fps={FPS} width={W} height={H} />
);
